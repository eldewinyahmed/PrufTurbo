Install:
cd /root/PrufTurbo
unzip -o pruefturbo_session_controls_complete_package.zip
python3 install_session_controls.py
python -m py_compile app/main.py
pkill -f uvicorn
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
