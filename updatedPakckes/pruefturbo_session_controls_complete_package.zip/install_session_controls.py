#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
ROOT=Path.cwd()
APP=ROOT/"app"
STATIC=APP/"static"
INDEX=APP/"templates"/"index.html"
MAIN=APP/"main.py"
STAMP=datetime.now().strftime("%Y%m%d_%H%M%S")
BACKUP=ROOT/("backup_session_controls_"+STAMP)
BACKUP.mkdir(exist_ok=True)

CSS = '#pt-session-toolbar{position:fixed;top:14px;right:18px;z-index:99999;display:flex;gap:8px;align-items:center;padding:8px;border:1px solid #d0d7de;border-radius:12px;background:rgba(255,255,255,.96);box-shadow:0 4px 16px rgba(0,0,0,.12)}#pt-session-toolbar button,#pt-session-toolbar a{font-family:Arial,sans-serif;font-size:13px;font-weight:700;border:0;border-radius:8px;padding:8px 11px;cursor:pointer;text-decoration:none;color:#fff}#pt-session-save{background:#2563eb}#pt-session-load{background:#0f766e}#pt-session-reset{background:#dc2626}#pt-session-logout{background:#374151}'
JS = '(function(){function r(f){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",f):f()}function c(){try{localStorage.clear();sessionStorage.clear()}catch(e){}document.querySelectorAll("input").forEach(e=>{if(["button","submit","reset","hidden"].includes((e.type||"").toLowerCase()))return;if(e.type==="checkbox"||e.type==="radio")e.checked=false;else e.value=""});document.querySelectorAll("textarea").forEach(e=>e.value="");document.querySelectorAll("select").forEach(e=>e.selectedIndex=0);["#caplPreview","#capl-viewer","#caplViewer","#generatedCapl","#generationResult","#generation-output","#kpiResult","#traceabilityResult","#testcaseTable","#dictionaryTable"].forEach(s=>document.querySelectorAll(s).forEach(e=>{"value"in e?e.value="":e.innerHTML=""}))}async function s(){try{const r=await fetch("/api/session/save",{credentials:"same-origin"});if(!r.ok)throw new Error("HTTP "+r.status);const b=await r.blob(),u=URL.createObjectURL(b),a=document.createElement("a");a.href=u;a.download="PruefTurbo_session_"+new Date().toISOString().replace(/[:.]/g,"-")+".json";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),2000)}catch(e){alert("Could not save session: "+e.message)}}function l(){const i=document.createElement("input");i.type="file";i.accept=".json,application/json";i.onchange=async()=>{const f=i.files&&i.files[0];if(!f)return;const fd=new FormData();fd.append("file",f);try{const r=await fetch("/api/session/load",{method:"POST",body:fd,credentials:"same-origin"}),j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.detail||("HTTP "+r.status));alert("Session loaded successfully.");location.reload()}catch(e){alert("Could not load session: "+e.message)}};i.click()}async function x(){if(!confirm("Reset session and clear all dynamic fields on all pages?"))return;try{await fetch("/api/session/reset",{method:"POST",credentials:"same-origin"})}catch(e){}c();location.reload()}r(function(){if(document.getElementById("pt-session-toolbar"))return;const b=document.createElement("div");b.id="pt-session-toolbar";b.innerHTML=\'<button id="pt-session-save" type="button">Save Session</button><button id="pt-session-load" type="button">Load Session</button><button id="pt-session-reset" type="button">Reset Session</button><a id="pt-session-logout" href="/logout">Logout</a>\';document.body.appendChild(b);document.getElementById("pt-session-save").onclick=s;document.getElementById("pt-session-load").onclick=l;document.getElementById("pt-session-reset").onclick=x})})();'

def backup(p):
    if p.exists():
        d=BACKUP/p.relative_to(ROOT)
        d.parent.mkdir(parents=True,exist_ok=True)
        d.write_bytes(p.read_bytes())

STATIC.mkdir(parents=True,exist_ok=True)
(STATIC/"pruefturbo_session_controls.css").write_text(CSS,encoding="utf-8")
(STATIC/"pruefturbo_session_controls.js").write_text(JS,encoding="utf-8")
print("OK static files installed")

if INDEX.exists():
    backup(INDEX)
    h=INDEX.read_text(encoding="utf-8",errors="ignore")
    changed=False
    if "pruefturbo_session_controls.css" not in h:
        tag='<link rel="stylesheet" href="/static/pruefturbo_session_controls.css">'
        h=h.replace("</head>","  "+tag+"\\n</head>",1) if "</head>" in h else tag+"\\n"+h
        changed=True
    if "pruefturbo_session_controls.js" not in h:
        tag='<script src="/static/pruefturbo_session_controls.js"></script>'
        h=h.replace("</body>","  "+tag+"\\n</body>",1) if "</body>" in h else h+"\\n"+tag+"\\n"
        changed=True
    if changed:
        INDEX.write_text(h,encoding="utf-8")
        print("OK index.html patched")
    else:
        print("OK index.html already patched")
else:
    print("WARN index.html not found")

if MAIN.exists():
    backup(MAIN)
    t=MAIN.read_text(encoding="utf-8",errors="ignore")
    changed=False
    if "RedirectResponse" not in t:
        t=t.replace("from fastapi.responses import FileResponse","from fastapi.responses import FileResponse, RedirectResponse")
        changed=True
    if '@app.get("/logout")' not in t and "@app.get('/logout')" not in t:
        t += '''
@app.get("/logout")
async def logout(response: Response):
    response = RedirectResponse(url="/login", status_code=303)
    response.delete_cookie("pt_auth")
    response.delete_cookie("pt_session_id")
    response.delete_cookie("session")
    return response
'''
        changed=True
    if '@app.post("/api/session/load")' not in t and "@app.post('/api/session/load')" not in t:
        t += '''
@app.post("/api/session/load")
async def load_session(request: Request, response: Response, file: UploadFile = File(...)):
    try:
        raw = await file.read()
        payload = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid session JSON: {exc}") from exc

    st = _state(request, response)
    if isinstance(payload, dict):
        if isinstance(payload.get("dictionary_rows"), list):
            st["dictionary_rows"] = payload["dictionary_rows"]
        restored = []
        for i, row in enumerate(payload.get("testcases", []) or [], start=2):
            try:
                builder = TestCaseBuilderPayload(
                    excel_row=row.get("excel_row") or i,
                    tc_id=row.get("tc_id", ""),
                    requirement_id=row.get("requirements", ""),
                    title=row.get("title", ""),
                    priority=row.get("priority", ""),
                    ecu=row.get("ecu", ""),
                    status=row.get("status", "Draft"),
                    extra_attrs=row.get("attrs", {}) if isinstance(row.get("attrs", {}), dict) else {}
                )
                restored.append(_payload_to_testcase(builder, builder.excel_row or i))
            except Exception:
                pass
        if restored:
            st["testcases"] = restored
            _refresh_testcase_names(st)
        st["last_output"] = None

    return {"ok": True, "testcases": [_tc_to_dict(tc) for tc in st.get("testcases", [])], "dictionary_count": len(st.get("dictionary_rows", []) or [])}
'''
        changed=True
    if changed:
        MAIN.write_text(t,encoding="utf-8")
        print("OK main.py patched")
    else:
        print("OK main.py already patched")
else:
    print("WARN main.py not found")

print("DONE backup:",BACKUP)
print("Next: python -m py_compile app/main.py")
