/* PruefTurbo UI Enhancements: generation download, load CAPL, load session, reset UI clear */
(function () {
  'use strict';

  const PT = window.PruefTurboUI = window.PruefTurboUI || {};
  PT.lastGeneratedDownloadUrl = null;
  PT.lastGeneratedFilename = null;

  function qs(sel) { return document.querySelector(sel); }
  function qsa(sel) { return Array.from(document.querySelectorAll(sel)); }

  function ensureTopRightToolbar() {
    let bar = document.getElementById('pt-top-right-toolbar');
    if (bar) return bar;
    bar = document.createElement('div');
    bar.id = 'pt-top-right-toolbar';
    bar.style.cssText = [
      'position:fixed', 'top:14px', 'right:18px', 'z-index:9999',
      'display:flex', 'gap:8px', 'align-items:center', 'flex-wrap:wrap',
      'background:rgba(255,255,255,0.92)', 'border:1px solid #d9e2ef',
      'border-radius:10px', 'padding:8px', 'box-shadow:0 3px 12px rgba(15,23,42,.08)'
    ].join(';');
    document.body.appendChild(bar);
    return bar;
  }

  function makeButton(id, text, onClick, title) {
    let btn = document.getElementById(id);
    if (!btn) {
      btn = document.createElement('button');
      btn.id = id;
      btn.type = 'button';
      btn.textContent = text;
      btn.title = title || text;
      btn.style.cssText = 'border:0;border-radius:8px;background:#2563eb;color:white;padding:8px 12px;font-weight:600;cursor:pointer;';
      btn.addEventListener('click', onClick);
    }
    return btn;
  }

  function showDownloadButton(url, filename) {
    if (!url) return;
    PT.lastGeneratedDownloadUrl = url;
    PT.lastGeneratedFilename = filename || 'generated.can';
    const bar = ensureTopRightToolbar();
    const btn = makeButton('pt-download-generated-btn', 'Download Generated File', function () {
      const a = document.createElement('a');
      a.href = PT.lastGeneratedDownloadUrl;
      a.download = PT.lastGeneratedFilename || '';
      document.body.appendChild(a);
      a.click();
      a.remove();
    }, 'Download the last generated CAPL/CAN file');
    if (!btn.parentElement) bar.appendChild(btn);
    btn.style.display = 'inline-block';
  }

  function findCaplViewer() {
    const selectors = [
      '#caplViewer', '#capl-viewer', '#caplPreview', '#capl-preview', '#generatedCapl',
      'textarea[name="capl"]', 'textarea[id*="capl" i]', 'pre[id*="capl" i]', 'code[id*="capl" i]'
    ];
    for (const s of selectors) {
      const el = qs(s);
      if (el) return el;
    }
    const candidates = qsa('textarea, pre, code').filter(el => /capl|generated|preview|viewer/i.test(el.id + ' ' + el.className + ' ' + (el.getAttribute('name') || '')));
    return candidates[0] || null;
  }

  function setViewerContent(text) {
    const viewer = findCaplViewer();
    if (!viewer) {
      let box = document.getElementById('pt-fallback-capl-viewer');
      if (!box) {
        box = document.createElement('textarea');
        box.id = 'pt-fallback-capl-viewer';
        box.style.cssText = 'width:100%;min-height:500px;margin-top:12px;font-family:monospace;white-space:pre;';
        const target = qs('#generation') || qs('[data-tab="generation"]') || document.body;
        target.appendChild(box);
      }
      box.value = text || '';
      return;
    }
    if ('value' in viewer) viewer.value = text || '';
    else viewer.textContent = text || '';
    viewer.style.maxHeight = 'none';
    viewer.style.height = 'auto';
    viewer.style.minHeight = '520px';
    viewer.style.overflow = 'auto';
    viewer.style.whiteSpace = 'pre';
  }

  function addLoadCaplButton() {
    const bar = ensureTopRightToolbar();
    let input = document.getElementById('pt-load-capl-input');
    if (!input) {
      input = document.createElement('input');
      input.id = 'pt-load-capl-input';
      input.type = 'file';
      input.accept = '.can,.cin,.capl,.txt';
      input.style.display = 'none';
      input.addEventListener('change', async function () {
        const file = input.files && input.files[0];
        if (!file) return;
        const text = await file.text();
        setViewerContent(text);
      });
      document.body.appendChild(input);
    }
    const btn = makeButton('pt-load-capl-btn', 'Load CAPL', function () { input.click(); }, 'Load a CAPL/CAN/TXT file into the viewer');
    if (!btn.parentElement) bar.appendChild(btn);
  }

  function addSessionButtons() {
    const bar = ensureTopRightToolbar();
    const loadBtn = makeButton('pt-load-session-btn', 'Load Session', function () {
      let input = document.getElementById('pt-load-session-input');
      if (!input) {
        input = document.createElement('input');
        input.id = 'pt-load-session-input';
        input.type = 'file';
        input.accept = '.json,application/json';
        input.style.display = 'none';
        input.addEventListener('change', async function () {
          const file = input.files && input.files[0];
          if (!file) return;
          const form = new FormData();
          form.append('file', file);
          try {
            const res = await fetch('/api/session/load', { method: 'POST', body: form });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.detail || res.statusText);
            alert('Session loaded successfully. The page will refresh.');
            location.reload();
          } catch (e) {
            alert('Session load failed: ' + e.message);
          }
        });
        document.body.appendChild(input);
      }
      input.click();
    }, 'Load saved PruefTurbo session JSON');
    if (!loadBtn.parentElement) bar.appendChild(loadBtn);
  }

  function clearDynamicFields() {
    qsa('input, textarea, select').forEach(el => {
      const type = (el.type || '').toLowerCase();
      if (['button', 'submit', 'reset', 'hidden'].includes(type)) return;
      if (type === 'checkbox' || type === 'radio') el.checked = false;
      else if (type === 'file') el.value = '';
      else el.value = '';
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    });
    qsa('[data-dynamic], .dynamic, .results, .preview, .generated, .kpi, .traceability').forEach(el => { el.innerHTML = ''; });
    setViewerContent('');
    const dl = document.getElementById('pt-download-generated-btn');
    if (dl) dl.style.display = 'none';
  }

  function wireResetButtons() {
    document.addEventListener('click', async function (e) {
      const el = e.target;
      if (!el) return;
      const txt = (el.textContent || '').trim().toLowerCase();
      const id = (el.id || '').toLowerCase();
      if (txt === 'reset session' || id.includes('reset-session')) {
        setTimeout(clearDynamicFields, 250);
      }
    }, true);
  }

  function patchFetch() {
    if (window.__ptFetchPatched) return;
    window.__ptFetchPatched = true;
    const originalFetch = window.fetch.bind(window);
    window.fetch = async function () {
      const res = await originalFetch.apply(this, arguments);
      try {
        const urlArg = arguments[0];
        const url = typeof urlArg === 'string' ? urlArg : (urlArg && urlArg.url) || '';
        if (/\/api\/generate-(direct|dictionary)/.test(url)) {
          const clone = res.clone();
          const data = await clone.json();
          if (data && data.download_url) {
            showDownloadButton(data.download_url, data.filename);
            try {
              const full = await originalFetch(data.download_url).then(r => r.text());
              setViewerContent(full);
            } catch (_) {
              if (data.preview) setViewerContent(data.preview);
            }
          }
        }
      } catch (_) { /* non-json or unrelated response */ }
      return res;
    };
  }

  document.addEventListener('DOMContentLoaded', function () {
    ensureTopRightToolbar();
    addLoadCaplButton();
    addSessionButtons();
    wireResetButtons();
    patchFetch();
  });
})();
