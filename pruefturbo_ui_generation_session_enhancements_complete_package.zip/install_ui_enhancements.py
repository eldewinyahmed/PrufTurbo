#!/usr/bin/env python3
from __future__ import annotations
import shutil
from pathlib import Path
from datetime import datetime

ROOT = Path.cwd()
APP = ROOT / 'app'
STATIC = APP / 'static'
TEMPLATES = APP / 'templates'
BACKUP = ROOT / ('backup_ui_enhancements_' + datetime.now().strftime('%Y%m%d_%H%M%S'))

JS_NAME = 'pruefturbo_ui_enhancements.js'
JS_SRC = ROOT / 'app' / 'static' / JS_NAME
JS_DST = STATIC / JS_NAME
MAIN = APP / 'main.py'
INDEX = TEMPLATES / 'index.html'

ENDPOINT_CODE = r'''

# --- PruefTurbo UI Enhancement: Load Session API ---
@app.post("/api/session/load")
async def load_session(request: Request, response: Response, file: UploadFile = File(...)):
    """Load a saved PruefTurbo session JSON created by /api/session/save."""
    st = _state(request, response)
    try:
        raw = file.file.read().decode("utf-8")
        payload = json.loads(raw)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid session JSON: {exc}") from exc

    try:
        rows = payload.get("dictionary_rows", []) or []
        st["dictionary_rows"] = rows
        if rows:
            _persist_dictionary(rows)

        loaded = []
        for i, item in enumerate(payload.get("testcases", []) or [], start=2):
            attrs = item.get("attrs") or {}
            if not attrs:
                attrs = {
                    "TC ID": item.get("tc_id", ""),
                    "Requirement ID": item.get("requirements", ""),
                    "TC title": item.get("title", ""),
                    "Priority": item.get("priority", ""),
                    "ECU": item.get("ecu", ""),
                    "Test Specification Status": item.get("status", ""),
                }
            row_no = int(item.get("excel_row") or i)
            all_text = "\n".join(str(v) for v in attrs.values())
            try:
                valid = not engine.is_placeholder_tc_id(attrs.get("TC ID", ""))
            except Exception:
                valid = True
            loaded.append(engine.TestCaseRow(
                excel_row=row_no,
                attributes=attrs,
                request_bytes=engine.parse_hex_bytes(attrs.get("Action", "")),
                expected_pattern=engine.parse_expected_pattern(attrs.get("Expectation", "")),
                has_timing_check=bool(__import__("re").search(r"timestamp|delta|response\s*time|OBD_GST_CONSTANT_ResponseTime", all_text, flags=__import__("re").IGNORECASE)),
                is_negative=bool(__import__("re").search(r"\b(NRC|negative|7F)\b", all_text, flags=__import__("re").IGNORECASE)),
                is_valid_for_generation=valid,
                generation_block_reason="" if valid else "Placeholder or missing Test Case ID; automatic CAPL generation skipped.",
            ))
        st["testcases"] = loaded
        st["last_output"] = None
        _refresh_testcase_names(st)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Failed to load session: {exc}") from exc

    return {"ok": True, "testcases": len(st.get("testcases", [])), "dictionary_rows": len(st.get("dictionary_rows", []))}
# --- End PruefTurbo UI Enhancement ---
'''

def backup(path: Path):
    if path.exists():
        rel = path.relative_to(ROOT)
        dst = BACKUP / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dst)

def inject_js():
    if not INDEX.exists():
        print('WARN: app/templates/index.html not found; skipping script injection')
        return
    backup(INDEX)
    text = INDEX.read_text(encoding='utf-8')
    tag = f'<script src="/static/{JS_NAME}"></script>'
    if tag in text:
        print('OK: JS tag already exists')
        return
    if '</body>' in text:
        text = text.replace('</body>', f'  {tag}\n</body>')
    else:
        text += '\n' + tag + '\n'
    INDEX.write_text(text, encoding='utf-8')
    print('OK: injected JS into index.html')

def patch_main():
    if not MAIN.exists():
        print('WARN: app/main.py not found; skipping backend patch')
        return
    backup(MAIN)
    text = MAIN.read_text(encoding='utf-8')
    if '@app.post("/api/session/load")' in text or "@app.post('/api/session/load')" in text:
        print('OK: /api/session/load already exists')
        return
    # Insert before traceability endpoint if possible, otherwise append
    marker = '@app.get("/api/traceability")'
    if marker in text:
        text = text.replace(marker, ENDPOINT_CODE + '\n' + marker)
    else:
        text += ENDPOINT_CODE
    MAIN.write_text(text, encoding='utf-8')
    print('OK: patched app/main.py with /api/session/load')

def main():
    if not APP.exists():
        raise SystemExit('ERROR: run this script from the PrufTurbo project root, e.g. /root/PrufTurbo')
    BACKUP.mkdir(exist_ok=True)
    STATIC.mkdir(parents=True, exist_ok=True)
    # If package extracted to root, JS source and destination are same; otherwise source may be in current folder
    local_js = ROOT / 'app' / 'static' / JS_NAME
    if not local_js.exists():
        raise SystemExit(f'ERROR: {local_js} missing. Extract the package from project root first.')
    backup(JS_DST)
    # no copy needed if same path, but keep message
    print('OK: UI enhancement JS is available at', JS_DST)
    inject_js()
    patch_main()
    print('\nDONE. Backup folder:', BACKUP)
    print('Next: python -m py_compile app/main.py && python -m uvicorn app.main:app --host 0.0.0.0 --port 8000')

if __name__ == '__main__':
    main()
