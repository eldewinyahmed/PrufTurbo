PruefTurbo UI Generation / CAPL Viewer / Session Enhancement Package
====================================================================

Safe install on Ubuntu server:

1) Upload this ZIP to /root/PrufTurbo
2) Stop app:
   pkill -f uvicorn

3) Backup project:
   cd /root
   cp -r PrufTurbo PrufTurbo_backup_$(date +%Y%m%d_%H%M%S)

4) Extract:
   cd /root/PrufTurbo
   unzip -o pruefturbo_ui_generation_session_enhancements_complete_package.zip

5) Run installer patch:
   python3 install_ui_enhancements.py

6) Activate venv and check syntax:
   source .venv/bin/activate
   python -m py_compile app/main.py

7) Start app:
   python -m uvicorn app.main:app --host 0.0.0.0 --port 8000

Features:
- Top-right toolbar with Download Generated File after generation
- Load CAPL button, reads .can/.cin/.txt into CAPL viewer
- Full generated CAPL viewer content fetched from download URL
- Load Session button beside session actions via top-right toolbar
- /api/session/load endpoint for saved session JSON
- Reset Session clears dynamic fields in UI

If the app fails, restore from the backup folder created by the installer or project backup.
